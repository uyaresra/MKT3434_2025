import sys
import numpy as np
import pandas as pd
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                           QHBoxLayout, QTabWidget, QPushButton, QLabel, 
                           QComboBox, QFileDialog, QSpinBox, QDoubleSpinBox,
                           QGroupBox, QScrollArea, QTextEdit, QStatusBar,
                           QProgressBar, QCheckBox, QGridLayout, QMessageBox,
                           QDialog, QListWidget, QLineEdit)
from PyQt6.QtCore import Qt
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from sklearn import datasets, preprocessing, model_selection
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score, mean_squared_error, confusion_matrix
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers
from tensorflow.keras import Sequential
from tensorflow.keras import layers, optimizers, utils
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import VGG16
from tensorflow.keras.layers import GlobalAveragePooling2D, Dense, Dropout
from tensorflow.keras.models import Model
from sklearn.metrics import f1_score
import io
from PIL import Image
from PIL.ImageQt import ImageQt
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import QThread, pyqtSignal







class TrainingThread(QThread):
    training_finished = pyqtSignal(object)

    def __init__(self, model, train_data, val_data, callbacks):
        super().__init__()
        self.model = model
        self.train_data = train_data
        self.val_data = val_data
        self.callbacks = callbacks

    def run(self):
        history = self.model.fit(
            *self.train_data,
            validation_data=self.val_data,
            epochs=5,
            batch_size=128,
            callbacks=self.callbacks
        )
        self.training_finished.emit(history)




class MLCourseGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Machine Learning Course GUI")
        self.setGeometry(100, 100, 1400, 800)
        
        # Initialize main widget and layout
        self.main_widget = QWidget()
        self.setCentralWidget(self.main_widget)
        self.layout = QVBoxLayout(self.main_widget)
        
        # Initialize data containers
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.current_model = None
        
        # Neural network configuration
        self.layer_config = []
        
        # Create components
        self.create_data_section()
        self.create_tabs()
        self.create_visualization()
        self.create_status_bar()
    def load_dataset(self):
        """Load selected dataset"""
        try:
            dataset_name = self.dataset_combo.currentText()
            
            if dataset_name == "Load Custom Dataset":
                return
            
            # Load selected dataset
            if dataset_name == "Iris Dataset":
                data = datasets.load_iris()
            elif dataset_name == "Breast Cancer Dataset":
                data = datasets.load_breast_cancer()
            elif dataset_name == "Digits Dataset":
                data = datasets.load_digits()
            elif dataset_name == "Boston Housing Dataset":
                data = datasets.load_boston()
            elif dataset_name == "MNIST Dataset":
                (X_train, y_train), (X_test, y_test) = tf.keras.datasets.mnist.load_data()
                self.X_train, self.X_test = X_train, X_test
                self.y_train, self.y_test = y_train, y_test
                self.status_bar.showMessage(f"Loaded {dataset_name}")
                return
            
            # Split data
            test_size = self.split_spin.value()
            self.X_train, self.X_test, self.y_train, self.y_test = \
                model_selection.train_test_split(data.data, data.target, 
                                              test_size=test_size, 
                                              random_state=42)
            
            # Apply scaling if selected
            self.apply_scaling()
            
            self.status_bar.showMessage(f"Loaded {dataset_name}")
            
        except Exception as e:
            self.show_error(f"Error loading dataset: {str(e)}")
    
    def load_custom_data(self):
        """Load custom dataset from CSV file"""
        try:
            file_name, _ = QFileDialog.getOpenFileName(
                self,
                "Load Dataset",
                "",
                "CSV files (*.csv)"
            )
            
            if file_name:
                # Load data
                data = pd.read_csv(file_name)
                
                # Ask user to select target column
                target_col = self.select_target_column(data.columns)
                
                if target_col:
                    X = data.drop(target_col, axis=1)
                    y = data[target_col]
                    
                    # Split data
                    test_size = self.split_spin.value()
                    self.X_train, self.X_test, self.y_train, self.y_test = \
                        model_selection.train_test_split(X, y, 
                                                      test_size=test_size, 
                                                      random_state=42)
                    
                    # Apply scaling if selected
                    self.apply_scaling()
                    
                    self.status_bar.showMessage(f"Loaded custom dataset: {file_name}")
                    
        except Exception as e:
            self.show_error(f"Error loading custom dataset: {str(e)}")
    
    def select_target_column(self, columns):
        """Dialog to select target column from dataset"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Select Target Column")
        layout = QVBoxLayout(dialog)
        
        combo = QComboBox()
        combo.addItems(columns)
        layout.addWidget(combo)
        
        btn = QPushButton("Select")
        btn.clicked.connect(dialog.accept)
        layout.addWidget(btn)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            return combo.currentText()
        return None
    
    def apply_scaling(self):
        """Apply selected scaling method to the data"""
        scaling_method = self.scaling_combo.currentText()
        
        if scaling_method != "No Scaling":
            try:
                if scaling_method == "Standard Scaling":
                    scaler = preprocessing.StandardScaler()
                elif scaling_method == "Min-Max Scaling":
                    scaler = preprocessing.MinMaxScaler()
                elif scaling_method == "Robust Scaling":
                    scaler = preprocessing.RobustScaler()
                
                self.X_train = scaler.fit_transform(self.X_train)
                self.X_test = scaler.transform(self.X_test)
                
            except Exception as e:
                self.show_error(f"Error applying scaling: {str(e)}")
    def create_data_section(self):
        """Create the data loading and preprocessing section"""
        data_group = QGroupBox("Data Management")
        data_layout = QHBoxLayout()
        
        # Dataset selection
        self.dataset_combo = QComboBox()
        self.dataset_combo.addItems([
            "Load Custom Dataset",
            "Iris Dataset",
            "Breast Cancer Dataset",
            "Digits Dataset",
            "Boston Housing Dataset",
            "MNIST Dataset"
        ])
        self.dataset_combo.currentIndexChanged.connect(self.load_dataset)
        
        # Data loading button
        self.load_btn = QPushButton("Load Data")
        self.load_btn.clicked.connect(self.load_custom_data)
        
        # Preprocessing options
        self.scaling_combo = QComboBox()
        self.scaling_combo.addItems([
            "No Scaling",
            "Standard Scaling",
            "Min-Max Scaling",
            "Robust Scaling"
        ])
        
        # Train-test split options
        self.split_spin = QDoubleSpinBox()
        self.split_spin.setRange(0.1, 0.9)
        self.split_spin.setValue(0.2)
        self.split_spin.setSingleStep(0.1)
        
        # Add widgets to layout
        data_layout.addWidget(QLabel("Dataset:"))
        data_layout.addWidget(self.dataset_combo)
        data_layout.addWidget(self.load_btn)
        data_layout.addWidget(QLabel("Scaling:"))
        data_layout.addWidget(self.scaling_combo)
        data_layout.addWidget(QLabel("Test Split:"))
        data_layout.addWidget(self.split_spin)
        
        data_group.setLayout(data_layout)
        self.layout.addWidget(data_group)
    
    def create_tabs(self):
        """Create tabs for different ML topics"""
        self.tab_widget = QTabWidget()
        
        # Create individual tabs
        tabs = [
            ("Classical ML", self.create_classical_ml_tab),
            ("Deep Learning", self.create_deep_learning_tab),
            ("Dimensionality Reduction", self.create_dim_reduction_tab),
            ("GAN", self.create_gan_tab),
            ("Reinforcement Learning", self.create_rl_tab)

        ]
        
        for tab_name, create_func in tabs:
            scroll = QScrollArea()
            tab_widget = create_func()
            scroll.setWidget(tab_widget)
            scroll.setWidgetResizable(True)
            self.tab_widget.addTab(scroll, tab_name)
        
        self.layout.addWidget(self.tab_widget)
    
    def create_classical_ml_tab(self):
        """Create the classical machine learning algorithms tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # Regression section
        regression_group = QGroupBox("Regression")
        regression_layout = QVBoxLayout()
        
        # Linear Regression
        lr_group = self.create_algorithm_group(
            "Linear Regression",
            {"fit_intercept": "checkbox",
             "normalize": "checkbox"}
        )
        regression_layout.addWidget(lr_group)
        
        # Logistic Regression
        logistic_group = self.create_algorithm_group(
            "Logistic Regression",
            {"C": "double",
             "max_iter": "int",
             "multi_class": ["ovr", "multinomial"]}
        )
        regression_layout.addWidget(logistic_group)
        
        regression_group.setLayout(regression_layout)
        layout.addWidget(regression_group, 0, 0)
        
        # Classification section
        classification_group = QGroupBox("Classification")
        classification_layout = QVBoxLayout()
        
        # Naive Bayes
        nb_group = self.create_algorithm_group(
            "Naive Bayes",
            {"var_smoothing": "double"}
        )
        classification_layout.addWidget(nb_group)
        
        # SVM
        svm_group = self.create_algorithm_group(
            "Support Vector Machine",
            {"C": "double",
             "kernel": ["linear", "rbf", "poly"],
             "degree": "int"}
        )
        classification_layout.addWidget(svm_group)
        
        # Decision Trees
        dt_group = self.create_algorithm_group(
            "Decision Tree",
            {"max_depth": "int",
             "min_samples_split": "int",
             "criterion": ["gini", "entropy"]}
        )
        classification_layout.addWidget(dt_group)
        
        # Random Forest
        rf_group = self.create_algorithm_group(
            "Random Forest",
            {"n_estimators": "int",
             "max_depth": "int",
             "min_samples_split": "int"}
        )
        classification_layout.addWidget(rf_group)
        
        # KNN
        knn_group = self.create_algorithm_group(
            "K-Nearest Neighbors",
            {"n_neighbors": "int",
             "weights": ["uniform", "distance"],
             "metric": ["euclidean", "manhattan"]}
        )
        classification_layout.addWidget(knn_group)
        
        classification_group.setLayout(classification_layout)
        layout.addWidget(classification_group, 0, 1)
        
        return widget
    
    def create_gan_tab(self):
        widget = QWidget()
        layout = QVBoxLayout()

        self.gan_label = QLabel("GAN Output will appear here")
        layout.addWidget(self.gan_label)

        self.train_gan_btn = QPushButton("Train GAN")
        self.train_gan_btn.clicked.connect(self.train_gan)
        layout.addWidget(self.train_gan_btn)

        self.gan_log = QTextEdit()
        self.gan_log.setReadOnly(True)
        layout.addWidget(self.gan_log)

        widget.setLayout(layout)
        return widget
    
    def train_gan(self):
        import numpy as np
        import matplotlib.pyplot as plt
        import io
        from PIL import Image
        from PIL.ImageQt import ImageQt
        from PyQt5.QtGui import QPixmap, QImage


        from tensorflow.keras.models import Sequential
        from tensorflow.keras.layers import Dense, LeakyReLU
        from tensorflow.keras.optimizers import Adam
        import tensorflow as tf

        # 1. GAN Yapısı
        def build_generator():
            model = Sequential([
                Dense(128, input_dim=100),
                LeakyReLU(0.2),
                Dense(784, activation="tanh")
            ])
            return model

        

        def build_discriminator():
            model = Sequential([
                Dense(128, input_dim=784),
                LeakyReLU(0.2),
                Dense(1, activation="sigmoid")
            ])
            model.compile(optimizer=Adam(0.0002), loss="binary_crossentropy", metrics=["accuracy"])
            return model

        generator = build_generator()
        discriminator = build_discriminator()

        # Combined GAN modeli
        discriminator.trainable = False
        z = tf.keras.Input(shape=(100,))
        img = generator(z)
        valid = discriminator(img)
        combined = tf.keras.Model(z, valid)
        combined.compile(optimizer=Adam(0.0002), loss="binary_crossentropy")

        # 2. Eğitim verisi
        (X_train, _), _ = tf.keras.datasets.mnist.load_data()
        X_train = X_train.reshape(-1, 784).astype("float32")
        X_train = (X_train - 127.5) / 127.5

        # 3. GAN Eğitimi
        batch_size = 64
        for epoch in range(1, 501):
            idx = np.random.randint(0, X_train.shape[0], batch_size)
            real_imgs = X_train[idx]

            noise = np.random.normal(0, 1, (batch_size, 100))
            gen_imgs = generator.predict(noise)

            d_loss_real = discriminator.train_on_batch(real_imgs, np.ones((batch_size, 1)))
            d_loss_fake = discriminator.train_on_batch(gen_imgs, np.zeros((batch_size, 1)))
            g_loss = combined.train_on_batch(noise, np.ones((batch_size, 1)))



            if epoch % 100 == 0:
                self.gan_log.append(f"Epoch {epoch} | D Loss: {d_loss_real[0]:.4f} | G Loss: {g_loss:.4f}")

                # Yeni görüntü üret
                noise = np.random.normal(0, 1, (1, 100))
                generated_img = generator.predict(noise).reshape(28, 28)

                # Görüntüyü matplotlib ile çiz
                fig = plt.figure(figsize=(1, 1))
                plt.axis('off')
                plt.imshow(generated_img, cmap="gray")

                # PNG olarak belleğe kaydet
                buf = io.BytesIO()
                plt.savefig(buf, format='png')
                plt.close(fig)
                buf.seek(0)

        img = Image.open(buf).convert("RGB")
        img_qt = ImageQt(img)  # ImageQt döner
        qimg = QImage(img_qt)  # Gerçek QImage'e dönüştür (bunu düzeltmek için direkt constructor'a sokma!)
        pixmap = QPixmap.fromImage(qimg)
        self.gan_label.setPixmap(pixmap)





    def create_dim_reduction_tab(self):
        """Create the dimensionality reduction tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # K-Means section
        kmeans_group = QGroupBox("K-Means Clustering")
        kmeans_layout = QVBoxLayout()
        
        kmeans_params = self.create_algorithm_group(
            "K-Means Parameters",
            {"n_clusters": "int",
             "max_iter": "int",
             "n_init": "int"}
        )
        kmeans_layout.addWidget(kmeans_params)
        
        kmeans_group.setLayout(kmeans_layout)
        layout.addWidget(kmeans_group, 0, 0)
        
        # PCA section
        pca_group = QGroupBox("Principal Component Analysis")
        pca_layout = QVBoxLayout()
        
        pca_params = self.create_algorithm_group(
            "PCA Parameters",
            {"n_components": "int",
             "whiten": "checkbox"}
        )
        pca_layout.addWidget(pca_params)
        
        pca_group.setLayout(pca_layout)
        layout.addWidget(pca_group, 0, 1)
        
        return widget
    
    def create_rl_tab(self):
        """Create the reinforcement learning tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # Environment selection
        env_group = QGroupBox("Environment")
        env_layout = QVBoxLayout()
        
        self.env_combo = QComboBox()
        self.env_combo.addItems([
            "CartPole-v1",
            "MountainCar-v0",
            "Acrobot-v1"
        ])
        env_layout.addWidget(self.env_combo)
        
        env_group.setLayout(env_layout)
        layout.addWidget(env_group, 0, 0)
        
        # RL Algorithm selection
        algo_group = QGroupBox("RL Algorithm")
        algo_layout = QVBoxLayout()
        
        self.rl_algo_combo = QComboBox()
        self.rl_algo_combo.addItems([
            "Q-Learning",
            "SARSA",
            "DQN"
        ])
        algo_layout.addWidget(self.rl_algo_combo)
        
        algo_group.setLayout(algo_layout)
        layout.addWidget(algo_group, 0, 1)
        
        return widget
    
    def create_visualization(self):
        """Create the visualization section"""
        viz_group = QGroupBox("Visualization")
        viz_layout = QHBoxLayout()
        
        # Create matplotlib figure
        self.figure = Figure(figsize=(8, 6))
        self.canvas = FigureCanvas(self.figure)
        viz_layout.addWidget(self.canvas)
        
        # Metrics display
        self.metrics_text = QTextEdit()
        self.metrics_text.setReadOnly(True)
        viz_layout.addWidget(self.metrics_text)
        
        viz_group.setLayout(viz_layout)
        self.layout.addWidget(viz_group)
    
    def create_status_bar(self):
        """Create the status bar"""
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        
        # Add progress bar
        self.progress_bar = QProgressBar()
        self.status_bar.addPermanentWidget(self.progress_bar)
    
    def create_algorithm_group(self, name, params):
        """Helper method to create algorithm parameter groups"""
        group = QGroupBox(name)
        layout = QVBoxLayout()
        
        # Create parameter inputs
        param_widgets = {}
        for param_name, param_type in params.items():
            param_layout = QHBoxLayout()
            param_layout.addWidget(QLabel(f"{param_name}:"))
            
            if param_type == "int":
                widget = QSpinBox()
                widget.setRange(1, 1000)
            elif param_type == "double":
                widget = QDoubleSpinBox()
                widget.setRange(0.0001, 1000.0)
                widget.setSingleStep(0.1)
            elif param_type == "checkbox":
                widget = QCheckBox()
            elif isinstance(param_type, list):
                widget = QComboBox()
                widget.addItems(param_type)
            
            param_layout.addWidget(widget)
            param_widgets[param_name] = widget
            layout.addLayout(param_layout)
        
        # Add train button
        train_btn = QPushButton(f"Train {name}")
        train_btn.clicked.connect(lambda: self.train_model(name, param_widgets))
        layout.addWidget(train_btn)
        
        group.setLayout(layout)
        return group

    def show_error(self, message):
        """Show error message dialog"""
        QMessageBox.critical(self, "Error", message)
       
    def create_deep_learning_tab(self):
        """Create the deep learning tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # MLP section
        mlp_group = QGroupBox("Multi-Layer Perceptron")
        mlp_layout = QVBoxLayout()
        
        # Layer configuration
        self.layer_config = []
        layer_btn = QPushButton("Add Layer")
        layer_btn.clicked.connect(self.add_layer_dialog)
        mlp_layout.addWidget(layer_btn)
        
        # Training parameters
        training_params_group = self.create_training_params_group()
        mlp_layout.addWidget(training_params_group)
        
        # Train button
        train_btn = QPushButton("Train Neural Network")
        train_btn.clicked.connect(self.train_neural_network)
        mlp_layout.addWidget(train_btn)
        
        mlp_group.setLayout(mlp_layout)
        layout.addWidget(mlp_group, 0, 0)
        
        # CNN section
        cnn_group = QGroupBox("Convolutional Neural Network")
        cnn_layout = QVBoxLayout()
        
        # CNN architecture controls
        cnn_controls = self.create_cnn_controls()
        cnn_layout.addWidget(cnn_controls)
        
        cnn_group.setLayout(cnn_layout)
        layout.addWidget(cnn_group, 0, 1)
        
        # RNN section
        rnn_group = QGroupBox("Recurrent Neural Network")
        rnn_layout = QVBoxLayout()
        
        # RNN architecture controls
        rnn_controls = self.create_rnn_controls()
        rnn_layout.addWidget(rnn_controls)
        
        rnn_group.setLayout(rnn_layout)
        layout.addWidget(rnn_group, 1, 0)
        
        return widget
    
 

    def add_layer_dialog(self):
        """Open a dialog to add a neural network layer"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Add Neural Network Layer")
        layout = QVBoxLayout(dialog)
        
        # Layer type selection
        type_layout = QHBoxLayout()
        type_label = QLabel("Layer Type:")
        type_combo = QComboBox()
        type_combo.addItems(["Dense", "Conv2D", "MaxPooling2D", "Flatten", "Dropout"])
        type_layout.addWidget(type_label)
        type_layout.addWidget(type_combo)
        layout.addLayout(type_layout)
        
        # Parameters input
        params_group = QGroupBox("Layer Parameters")
        params_layout = QVBoxLayout()
        
        # Dynamic parameter inputs based on layer type
        self.layer_param_inputs = {}
        
        def update_params():
            # Clear existing parameter inputs
            for widget in list(self.layer_param_inputs.values()):
                params_layout.removeWidget(widget)
                widget.deleteLater()
            self.layer_param_inputs.clear()
            
            layer_type = type_combo.currentText()
            if layer_type == "Dense":
                units_label = QLabel("Units:")
                units_input = QSpinBox()
                units_input.setRange(1, 1000)
                units_input.setValue(32)
                self.layer_param_inputs["units"] = units_input
                
                activation_label = QLabel("Activation:")
                activation_combo = QComboBox()
                activation_combo.addItems(["relu", "sigmoid", "tanh", "softmax"])
                self.layer_param_inputs["activation"] = activation_combo
                
                params_layout.addWidget(units_label)
                params_layout.addWidget(units_input)
                params_layout.addWidget(activation_label)
                params_layout.addWidget(activation_combo)
            
            elif layer_type == "Conv2D":
                filters_label = QLabel("Filters:")
                filters_input = QSpinBox()
                filters_input.setRange(1, 1000)
                filters_input.setValue(32)
                self.layer_param_inputs["filters"] = filters_input
                
                kernel_label = QLabel("Kernel Size:")
                kernel_input = QLineEdit()
                kernel_input.setText("3, 3")
                self.layer_param_inputs["kernel_size"] = kernel_input
                
                params_layout.addWidget(filters_label)
                params_layout.addWidget(filters_input)
                params_layout.addWidget(kernel_label)
                params_layout.addWidget(kernel_input)
            
            elif layer_type == "Dropout":
                rate_label = QLabel("Dropout Rate:")
                rate_input = QDoubleSpinBox()
                rate_input.setRange(0.0, 1.0)
                rate_input.setValue(0.5)
                rate_input.setSingleStep(0.1)
                self.layer_param_inputs["rate"] = rate_input
                
                params_layout.addWidget(rate_label)
                params_layout.addWidget(rate_input)
        
        type_combo.currentIndexChanged.connect(update_params)
        update_params()  # Initial update
        
        params_group.setLayout(params_layout)
        layout.addWidget(params_group)
        
        # Buttons
        btn_layout = QHBoxLayout()
        add_btn = QPushButton("Add Layer")
        cancel_btn = QPushButton("Cancel")
        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)
        
        def add_layer():
            layer_type = type_combo.currentText()
            
            # Collect parameters
            layer_params = {}
            for param_name, widget in self.layer_param_inputs.items():
                if isinstance(widget, QSpinBox):
                    layer_params[param_name] = widget.value()
                elif isinstance(widget, QDoubleSpinBox):
                    layer_params[param_name] = widget.value()
                elif isinstance(widget, QComboBox):
                    layer_params[param_name] = widget.currentText()
                elif isinstance(widget, QLineEdit):
                    # Handle kernel size or other tuple-like inputs
                    if param_name == "kernel_size":
                        layer_params[param_name] = tuple(map(int, widget.text().split(',')))
            
            self.layer_config.append({
                "type": layer_type,
                "params": layer_params
            })
            
            dialog.accept()
        
        add_btn.clicked.connect(add_layer)
        cancel_btn.clicked.connect(dialog.reject)
        
        dialog.exec()
    
    def create_training_params_group(self):
        """Create group for neural network training parameters"""
        group = QGroupBox("Training Parameters")
        layout = QVBoxLayout()
        
        # Batch size
        batch_layout = QHBoxLayout()
        batch_layout.addWidget(QLabel("Batch Size:"))
        self.batch_size_spin = QSpinBox()
        self.batch_size_spin.setRange(1, 1000)
        self.batch_size_spin.setValue(32)
        batch_layout.addWidget(self.batch_size_spin)
        layout.addLayout(batch_layout)
        
        # Epochs
        epochs_layout = QHBoxLayout()
        epochs_layout.addWidget(QLabel("Epochs:"))
        self.epochs_spin = QSpinBox()
        self.epochs_spin.setRange(1, 1000)
        self.epochs_spin.setValue(10)
        epochs_layout.addWidget(self.epochs_spin)
        layout.addLayout(epochs_layout)
        
        # Learning rate
        lr_layout = QHBoxLayout()
        lr_layout.addWidget(QLabel("Learning Rate:"))
        self.lr_spin = QDoubleSpinBox()
        self.lr_spin.setRange(0.0001, 1.0)
        self.lr_spin.setValue(0.001)
        self.lr_spin.setSingleStep(0.001)
        lr_layout.addWidget(self.lr_spin)
        layout.addLayout(lr_layout)
        
        group.setLayout(layout)
        return group
    
    def add_pooling_layer(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Add MaxPooling2D Layer")
        layout = QVBoxLayout(dialog)

        pool_label = QLabel("Pool Size (örnek: 2,2):")
        pool_input = QLineEdit()
        pool_input.setText("2,2")
        layout.addWidget(pool_label)
        layout.addWidget(pool_input)

        ok_btn = QPushButton("Add")
        cancel_btn = QPushButton("Cancel")
        btn_layout = QHBoxLayout()
        btn_layout.addWidget(ok_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)

        def on_ok():
            try:
                pool_size = tuple(map(int, pool_input.text().split(",")))
                config = {
                    "type": "MaxPooling2D",
                    "params": {
                        "pool_size": pool_size
                    }
                }
                self.cnn_layer_config.append(config)
                dialog.accept()
            except Exception as e:
                QMessageBox.warning(self, "Input Error", f"Invalid pool size: {e}")

        ok_btn.clicked.connect(on_ok)
        cancel_btn.clicked.connect(dialog.reject)

        dialog.exec()

    def add_dropout_layer(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Add Dropout Layer")
        layout = QVBoxLayout(dialog)

        rate_label = QLabel("Dropout Rate (0.0 - 1.0):")
        rate_input = QDoubleSpinBox()
        rate_input.setRange(0.0, 1.0)
        rate_input.setSingleStep(0.1)
        rate_input.setValue(0.5)
        layout.addWidget(rate_label)
        layout.addWidget(rate_input)

        # Butonlar
        ok_btn = QPushButton("Add")
        cancel_btn = QPushButton("Cancel")
        btn_layout = QHBoxLayout()
        btn_layout.addWidget(ok_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)

        def on_ok():
            config = {
                "type": "Dropout",
                "params": {
                    "rate": rate_input.value()
                }
            }
            self.cnn_layer_config.append(config)
            dialog.accept()

        ok_btn.clicked.connect(on_ok)
        cancel_btn.clicked.connect(dialog.reject)

        dialog.exec()

    def add_flatten_layer(self):
        config = {
            "type": "Flatten",
            "params": {}
        }
        self.cnn_layer_config.append(config)
        QMessageBox.information(self, "Layer Added", "Flatten layer added to CNN.")

    def add_conv_layer(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Add Conv2D Layer")
        layout = QVBoxLayout(dialog)
            
        self.layer_param_inputs = {}

        # Filter sayısı
        filter_label = QLabel("Filters:")
        filter_spin = QSpinBox()
        filter_spin.setRange(1, 512)
        filter_spin.setValue(32)
        layout.addWidget(filter_label)
        layout.addWidget(filter_spin)

        # Kernel size
        kernel_label = QLabel("Kernel Size (örnek: 3,3):")
        kernel_input = QLineEdit()
        kernel_input.setText("3,3")
        layout.addWidget(kernel_label)
        layout.addWidget(kernel_input)

        # Activation function
        act_label = QLabel("Activation:")
        act_combo = QComboBox()
        act_combo.addItems(["relu", "sigmoid", "tanh"])
        layout.addWidget(act_label)
        layout.addWidget(act_combo)

        # L2 regularizer
        l2_label = QLabel("L2 (0.0 - 0.1):")
        l2_input = QDoubleSpinBox()
        l2_input.setRange(0.0, 1.0)
        l2_input.setSingleStep(0.01)
        l2_input.setValue(0.00)
        layout.addWidget(l2_label)
        layout.addWidget(l2_input)


        self.layer_param_inputs["l2"] = l2_input


        # OK ve Cancel butonları
        btn_layout = QHBoxLayout()
        ok_btn = QPushButton("Add")
        cancel_btn = QPushButton("Cancel")
        btn_layout.addWidget(ok_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)

        def on_ok():
            try:
                kernel = tuple(map(int, kernel_input.text().split(",")))
                config = {
                    "type": "Conv2D",
                    "params": {
                    "filters": filter_spin.value(),
                    "kernel_size": kernel,
                    "activation": act_combo.currentText()
                }
                
                }
                self.cnn_layer_config.append(config)
                self.layer_list_widget.addItem(
                    f"Conv2D - filters={filter_spin.value()}, kernel={kernel_input.text()}, activation={act_combo.currentText()}"
                )

                dialog.accept()
            except Exception as e:
                QMessageBox.warning(self, "Input Error", f"Invalid kernel size: {e}")
            
        ok_btn.clicked.connect(on_ok)
        cancel_btn.clicked.connect(dialog.reject)
            
        dialog.exec()

    def create_cnn_controls(self): 
        """Create controls for Convolutional Neural Network"""
        group = QGroupBox("CNN Architecture")
        layout = QVBoxLayout()
        
        # CNN katman konfigürasyonları burada tutulur
        self.cnn_layer_config = []

        # Conv2D ekleme butonu
        add_conv_btn = QPushButton("Add Conv2D Layer")
        add_conv_btn.clicked.connect(self.add_conv_layer)
        layout.addWidget(add_conv_btn)

        # MaxPooling ekleme butonu
        add_pool_btn = QPushButton("Add MaxPooling2D Layer")
        add_pool_btn.clicked.connect(self.add_pooling_layer)
        layout.addWidget(add_pool_btn)
        
        # Flatten katmanı (zorunlu katman)
        add_flatten_btn = QPushButton("Add Flatten Layer")
        add_flatten_btn.clicked.connect(self.add_flatten_layer)
        layout.addWidget(add_flatten_btn)
        
        # Dropout katmanı
        add_dropout_btn = QPushButton("Add Dropout Layer")
        add_dropout_btn.clicked.connect(self.add_dropout_layer)
        layout.addWidget(add_dropout_btn)
        
        # Optimizer seçimi
        self.cnn_optimizer_combo = QComboBox()
        self.cnn_optimizer_combo.addItems(["Adam", "SGD", "RMSprop"])
        layout.addWidget(QLabel("Optimizer:"))
        layout.addWidget(self.cnn_optimizer_combo)

        # Learning rate scheduler seçimi
        self.lr_scheduler_combo = QComboBox()
        self.lr_scheduler_combo.addItems(["None", "Step Decay", "Exponential Decay"])
        layout.addWidget(QLabel("LR Scheduler:"))
        layout.addWidget(self.lr_scheduler_combo)

        # Data Augmentation checkbox'ları
        self.aug_flip = QCheckBox("Horizontal Flip")
        self.aug_rotation = QCheckBox("Rotation (15 deg)")
        self.aug_zoom = QCheckBox("Zoom (0.1)")

        layout.addWidget(QLabel("Data Augmentation Options:"))
        layout.addWidget(self.aug_flip)
        layout.addWidget(self.aug_rotation)
        layout.addWidget(self.aug_zoom)

        # VGG16 kullanımı için checkbox
        self.use_vgg_checkbox = QCheckBox("Use Pre-trained VGG16 (ImageNet)")
        layout.addWidget(self.use_vgg_checkbox)

        # Eğitim başlatma butonu
        train_btn = QPushButton("Train CNN")
        train_btn.clicked.connect(self.train_cnn_network)
        layout.addWidget(train_btn)

        # Model kaydetme butonu
        save_btn = QPushButton("Save CNN Model")
        save_btn.clicked.connect(self.save_cnn_model)
        layout.addWidget(save_btn)

        # Model yükleme butonu
        load_btn = QPushButton("Load CNN Model")
        load_btn.clicked.connect(self.load_cnn_model)
        layout.addWidget(load_btn)

        self.layer_list_widget = QListWidget()
        layout.addWidget(QLabel("CNN Layer Stack:"))
        layout.addWidget(self.layer_list_widget)

        remove_btn = QPushButton("Remove Selected Layer")
        remove_btn.clicked.connect(self.remove_selected_layer)
        layout.addWidget(remove_btn)


        
        group.setLayout(layout)
        
        return group

    def remove_selected_layer(self):
        selected_row = self.layer_list_widget.currentRow()
        if selected_row >= 0:
            # Liste görünümünden ve konfig listesinden sil
                self.layer_list_widget.takeItem(selected_row)
                del self.cnn_layer_config[selected_row]
        else:
            QMessageBox.information(self, "No Selection", "Please select a layer to remove.")

    def save_cnn_model(self):
        try:
            file_name, _ = QFileDialog.getSaveFileName(self, "Save CNN Model", "", "HDF5 files (*.h5)")
            if file_name:
                self.cnn_model.save(file_name)
                QMessageBox.information(self, "Model Saved", f"Model saved to: {file_name}")
        except Exception as e:
            QMessageBox.critical(self, "Save Error", str(e))

    def load_cnn_model(self):
        try:
            file_name, _ = QFileDialog.getOpenFileName(self, "Load CNN Model", "", "HDF5 files (*.h5)")
            if file_name:
                self.cnn_model = tf.keras.models.load_model(file_name)
                QMessageBox.information(self, "Model Loaded", f"Model loaded from: {file_name}")
        except Exception as e:
            QMessageBox.critical(self, "Load Error", str(e))

    def create_rnn_controls(self):
        """Create controls for Recurrent Neural Network"""
        group = QGroupBox("RNN Architecture")
        layout = QVBoxLayout()
        
        # Placeholder for RNN-specific controls
        label = QLabel("RNN Controls (To be implemented)")
        layout.addWidget(label)
        
        group.setLayout(layout)
        return group
    

    def train_cnn_network(self):
        try:
            # Veriyi yükle
            (X_train, y_train), (X_test, y_test) = tf.keras.datasets.mnist.load_data()
            X_train = X_train.astype("float32") / 255.
            X_test = X_test.astype("float32") / 255.

            if self.use_vgg_checkbox.isChecked():
                # VGG için RAM dostu subset (örnekleme)
                X_train = X_train[:3000]
                y_train = y_train[:3000]

                X_train = tf.image.resize(X_train[..., tf.newaxis], [224, 224])
                X_test = tf.image.resize(X_test[..., tf.newaxis], [224, 224])
                X_train = tf.image.grayscale_to_rgb(X_train)
                X_test = tf.image.grayscale_to_rgb(X_test)
                input_shape = (224, 224, 3)

            else:
                X_train = X_train.reshape((-1, 28, 28, 1))
                X_test = X_test.reshape((-1, 28, 28, 1))
                input_shape = (28, 28, 1)

            y_train = tf.keras.utils.to_categorical(y_train, 10)
            y_test = tf.keras.utils.to_categorical(y_test, 10)

            # Modeli oluştur
            if self.use_vgg_checkbox.isChecked():
                base_model = VGG16(include_top=False, weights='imagenet', input_shape=input_shape)
                base_model.trainable = False
                x = base_model.output
                x = GlobalAveragePooling2D()(x)
                x = Dense(128, activation='relu')(x)
                x = Dropout(0.5)(x)
                predictions = Dense(10, activation='softmax')(x)
                model = Model(inputs=base_model.input, outputs=predictions)
            else:
                if not self.cnn_layer_config:
                    QMessageBox.warning(self, "Empty Network", "Please add CNN layers first.")
                    return
                model = Sequential()
                first_layer = True
                for layer_cfg in self.cnn_layer_config:
                    layer_type = layer_cfg["type"]
                    params = layer_cfg["params"]
                    if "l2" in params:
                        from tensorflow.keras import regularizers
                        l2_val = params.pop("l2")
                        if l2_val > 0.0:
                            params["kernel_regularizer"] = regularizers.l2(l2_val)

                    if first_layer and layer_type == "Conv2D":
                        model.add(layers.Conv2D(**params, input_shape=input_shape))
                        first_layer = False
                    elif layer_type == "Conv2D":
                        model.add(layers.Conv2D(**params))
                    elif layer_type == "MaxPooling2D":
                        model.add(layers.MaxPooling2D(**params))
                    elif layer_type == "Flatten":
                        model.add(layers.Flatten())
                    elif layer_type == "Dropout":
                        model.add(layers.Dropout(**params))
                model.add(Dense(10, activation="softmax"))

            # Optimizer
            selected_opt = self.cnn_optimizer_combo.currentText()
            if selected_opt == "Adam":
                optimizer = optimizers.Adam()
            elif selected_opt == "SGD":
                optimizer = optimizers.SGD()
            elif selected_opt == "RMSprop":
                optimizer = optimizers.RMSprop()
            else:
                optimizer = optimizers.Adam()

            model.compile(optimizer=optimizer,
                            loss="categorical_crossentropy",
                            metrics=["accuracy"])

            # Callbacks
            callbacks = [self.create_progress_callback()]
            selected_scheduler = self.lr_scheduler_combo.currentText()
            if selected_scheduler == "Step Decay":
                def step_decay(epoch, lr):
                    return lr * (0.5 ** (epoch // 2))
                callbacks.append(tf.keras.callbacks.LearningRateScheduler(step_decay))
            elif selected_scheduler == "Exponential Decay":
                def exp_decay(epoch, lr):
                    return lr * tf.math.exp(-0.1 * epoch)
                callbacks.append(tf.keras.callbacks.LearningRateScheduler(exp_decay))

            # Augmentasyon
            datagen_args = {"rescale": None}
            if self.aug_flip.isChecked():
                datagen_args["horizontal_flip"] = True
            if self.aug_rotation.isChecked():
                datagen_args["rotation_range"] = 15
            if self.aug_zoom.isChecked():
                datagen_args["zoom_range"] = 0.1

            datagen = ImageDataGenerator(**datagen_args)
            datagen.fit(X_train)

            # Eğitim
            history = model.fit(
                datagen.flow(X_train, y_train, batch_size=128),
                epochs=3,
                validation_data=(X_test, y_test),
                callbacks=callbacks
            )

            self.cnn_model = model
            self.plot_training_history(history)
            self.status_bar.showMessage("CNN Training Complete")

            # Ağırlık histogramı çizimi (ilk katman)
            weights = model.layers[0].get_weights()[0]

            import matplotlib.pyplot as plt
            plt.figure(figsize=(6, 4))
            plt.hist(weights.flatten(), bins=50, color='skyblue', edgecolor='black')
            plt.title("Weight Histogram of First Layer")
            plt.xlabel("Weight Value")
            plt.ylabel("Frequency")
            plt.grid(True)
            plt.tight_layout()
            plt.savefig("weight_histogram.png")
            plt.close()


            # Eğitim işlemini ayrı bir thread’de başlat
            self.training_thread = TrainingThread(model,
                                                rain_data=(X_train, y_train),
                                                val_data=(X_test, y_test),
                                                callbacks=callbacks)
            self.training_thread.training_finished.connect(self.training_done)
            self.training_thread.start()


            # Tahmin ve F1-score
            y_pred_probs = model.predict(X_test)
            y_pred = np.argmax(y_pred_probs, axis=1)
            y_true = np.argmax(y_test, axis=1)
            f1 = f1_score(y_true, y_pred, average='macro')
            self.metrics_text.append(f"\nF1 Score (macro): {f1:.4f}")

        except Exception as e:
            QMessageBox.critical(self, "Training Error", str(e))

    def training_done(self, history):
        self.plot_training_history(history)
        self.status_bar.showMessage("CNN Training Complete")
        self.cnn_model = self.training_thread.model

    def train_neural_network(self):
        """Train the neural network with current configuration"""
        if not self.layer_config:
            self.show_error("Please add at least one layer to the network")
            return
        
        try:
            # Create and compile model
            model = self.create_neural_network()
            
            # Get training parameters
            batch_size = self.batch_size_spin.value()
            epochs = self.epochs_spin.value()
            learning_rate = self.lr_spin.value()
            
            # Prepare data for neural network
            if len(self.X_train.shape) == 1:
                X_train = self.X_train.reshape(-1, 1)
                X_test = self.X_test.reshape(-1, 1)
            else:
                X_train = self.X_train
                X_test = self.X_test
            
            # One-hot encode target for classification
            y_train = tf.keras.utils.to_categorical(self.y_train)
            y_test = tf.keras.utils.to_categorical(self.y_test)
            
            # Compile model
            optimizer = optimizers.Adam(learning_rate=learning_rate)
            model.compile(optimizer=optimizer,
                          loss='categorical_crossentropy',
                          metrics=['accuracy'])
            
            # Train model
            history = model.fit(X_train, y_train,
                                batch_size=batch_size,
                                epochs=epochs,
                                validation_data=(X_test, y_test),
                                callbacks=[self.create_progress_callback()])
            
            # Update visualization with training history
            self.plot_training_history(history)
            
            self.status_bar.showMessage("Neural Network Training Complete")
            
        except Exception as e:
            self.show_error(f"Error training neural network: {str(e)}")
    
    def create_neural_network(self):
        """Create neural network based on current configuration"""
        model = models.Sequential()
        
        # Add layers based on configuration
        for layer_config in self.layer_config:
            layer_type = layer_config["type"]
            params = layer_config["params"]
            
            if layer_type == "Dense":
                model.add(layers.Dense(**params))
            elif layer_type == "Conv2D":
                # Add input shape for the first layer
                if len(model.layers) == 0:
                    params['input_shape'] = self.X_train.shape[1:]
                model.add(layers.Conv2D(**params))
            elif layer_type == "MaxPooling2D":
                model.add(layers.MaxPooling2D())
            elif layer_type == "Flatten":
                model.add(layers.Flatten())
            elif layer_type == "Dropout":
                model.add(layers.Dropout(**params))
        
        # Add output layer based on number of classes
        num_classes = len(np.unique(self.y_train))
        model.add(layers.Dense(num_classes, activation='softmax'))
                
        return model

   
        
    def train_neural_network(self):
        """Train the neural network"""
        try:
            # Create and compile model
            model = self.create_neural_network()
            
            # Get training parameters
            batch_size = self.batch_size_spin.value()
            epochs = self.epochs_spin.value()
            learning_rate = self.lr_spin.value()
            
            # Compile model
            optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
            model.compile(optimizer=optimizer,
                        loss='categorical_crossentropy',
                        metrics=['accuracy'])
            
            # Train model
            history = model.fit(self.X_train, self.y_train,
                              batch_size=batch_size,
                              epochs=epochs,
                              validation_data=(self.X_test, self.y_test),
                              callbacks=[self.create_progress_callback()])
            
            # Update visualization with training history
            self.plot_training_history(history)
            
        except Exception as e:
            self.show_error(f"Error training neural network: {str(e)}")
            
    def create_progress_callback(self):
        """Create callback for updating progress bar during training"""
        class ProgressCallback(tf.keras.callbacks.Callback):
            def __init__(self, progress_bar):
                super().__init__()
                self.progress_bar = progress_bar
                
            def on_epoch_end(self, epoch, logs=None):
                progress = int(((epoch + 1) / self.params['epochs']) * 100)
                self.progress_bar.setValue(progress)
                
        return ProgressCallback(self.progress_bar)
        
    def update_visualization(self, y_pred):
        """Update the visualization with current results"""
        self.figure.clear()
        
        # Create appropriate visualization based on data
        if len(np.unique(self.y_test)) > 10:  # Regression
            ax = self.figure.add_subplot(111)
            ax.scatter(self.y_test, y_pred)
            ax.plot([self.y_test.min(), self.y_test.max()],
                   [self.y_test.min(), self.y_test.max()],
                   'r--', lw=2)
            ax.set_xlabel("Actual Values")
            ax.set_ylabel("Predicted Values")
            
        else:  # Classification
            if self.X_train.shape[1] > 2:  # Use PCA for visualization
                pca = PCA(n_components=2)
                X_test_2d = pca.fit_transform(self.X_test)
                
                ax = self.figure.add_subplot(111)
                scatter = ax.scatter(X_test_2d[:, 0], X_test_2d[:, 1],
                                   c=y_pred, cmap='viridis')
                self.figure.colorbar(scatter)
                
            else:  # Direct 2D visualization
                ax = self.figure.add_subplot(111)
                scatter = ax.scatter(self.X_test[:, 0], self.X_test[:, 1],
                                   c=y_pred, cmap='viridis')
                self.figure.colorbar(scatter)
        
        self.canvas.draw()
        
    def update_metrics(self, y_pred):
        """Update metrics display"""
        metrics_text = "Model Performance Metrics:\n\n"
        
        # Calculate appropriate metrics based on problem type
        if len(np.unique(self.y_test)) > 10:  # Regression
            mse = mean_squared_error(self.y_test, y_pred)
            rmse = np.sqrt(mse)
            r2 = self.current_model.score(self.X_test, self.y_test)
            
            metrics_text += f"Mean Squared Error: {mse:.4f}\n"
            metrics_text += f"Root Mean Squared Error: {rmse:.4f}\n"
            metrics_text += f"R² Score: {r2:.4f}"
            
        else:  # Classification
            accuracy = accuracy_score(self.y_test, y_pred)
            conf_matrix = confusion_matrix(self.y_test, y_pred)
            
            metrics_text += f"Accuracy: {accuracy:.4f}\n\n"
            metrics_text += "Confusion Matrix:\n"
            metrics_text += str(conf_matrix)
        
        self.metrics_text.setText(metrics_text)
        
    def plot_training_history(self, history):
        """Plot neural network training history"""
        self.figure.clear()
        
        # Plot training & validation accuracy
        ax1 = self.figure.add_subplot(211)
        ax1.plot(history.history['accuracy'])
        ax1.plot(history.history['val_accuracy'])
        ax1.set_title('Model Accuracy')
        ax1.set_ylabel('Accuracy')
        ax1.set_xlabel('Epoch')
        ax1.legend(['Train', 'Test'])
        
        # Plot training & validation loss
        ax2 = self.figure.add_subplot(212)
        ax2.plot(history.history['loss'])
        ax2.plot(history.history['val_loss'])
        ax2.set_title('Model Loss')
        ax2.set_ylabel('Loss')
        ax2.set_xlabel('Epoch')
        ax2.legend(['Train', 'Test'])
        
        self.figure.tight_layout()
        self.canvas.draw()
        
    def show_error(self, message):
        """Show error message dialog"""
        QMessageBox.critical(self, "Error", message)

def main():
    """Main function to start the application"""
    app = QApplication(sys.argv)
    window = MLCourseGUI()
    window.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    main()
